import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../constants.dart';

class CustomTextfield extends StatelessWidget{
  CustomTextfield(this.input,this.hint,this.controller,this.onChange);

  final TextInputType input;
  final String hint;
  final TextEditingController controller;
  final Function(String)? onChange;

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      onChanged: onChange,
      keyboardType: input,
      textAlign: TextAlign.center,
      decoration: kTextFieldInputDecoration.copyWith(hintText: hint),
    );
  }

}