import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:sa_app/widgets/google_button.dart';

class LoginScreen extends StatefulWidget {
  static String idl = 'login_screen';

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  bool showSpinner = false;
  late String email;
  late String password;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFF033d5b),
        title: Text('Solution Analysts'),
        centerTitle: true,
      ),
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.white,
      body: Container(
          height: double.infinity,
          width: double.infinity,
          child: Column(
            children: [
              Container(
                child: Image.asset('assets/images/label.png'),
              ),
              SizedBox(height: 30.0,),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 24.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    GoogleButton(),
                  ],
                ),
              ),
            ],
          ),
        ),
        );
  }
}