import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:sa_app/model/curd.dart';

final _firestore = FirebaseFirestore.instance;

class EmpList extends StatefulWidget {
  const EmpList({Key? key}) : super(key: key);

  @override
  State<EmpList> createState() => _EmpListState();
}

class _EmpListState extends State<EmpList> {
  late QuerySnapshot employees;


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _employeeList(),
    );
  }

  Widget _employeeList() {
    return StreamBuilder<QuerySnapshot>(
      stream: _firestore
          .collection('emp')
          .doc(FirebaseAuth.instance.currentUser?.email)
          .collection('empDetails')
          .snapshots(),
      builder: (context, AsyncSnapshot<QuerySnapshot> snapshot) {
        if (!snapshot.hasData) {
          return const Center(
            child: CircularProgressIndicator(),
          );
        }
        return ListView.builder(
          itemCount: snapshot.data?.docs.length,
          itemBuilder: (ctx, i) {
            final doc = snapshot.data?.docs[i];
            return Card(
              child: ListTile(
                title: Text(doc![i]['name']),
                subtitle: Text(doc[i]['city']),
                trailing: IconButton(
                  onPressed: () {
                    _firestore
                        .collection('emp')
                        .doc(FirebaseAuth.instance.currentUser?.email)
                        .collection('empDetails')
                        .doc(doc[i].id)
                        .delete();
                  },
                  icon: Icon(
                    Icons.delete,
                    color: Colors.red,
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }
}
