import 'package:flutter/material.dart';
import 'package:sa_app/model/curd.dart';
import 'package:sa_app/widgets/button.dart';
import 'package:sa_app/widgets/textfield.dart';

class AddEmployee extends StatefulWidget{

  @override
  State<AddEmployee> createState() => _AddEmployeeState();
}

class _AddEmployeeState extends State<AddEmployee> {

  late String name;
  late String city;
  late String mentor;

  final nameController = TextEditingController();
  final cityController = TextEditingController();
  final mentorController = TextEditingController();

  curdMethods curdObj = curdMethods();

  void clear() {
    nameController.clear();
    cityController.clear();
    mentorController.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Card(
        margin: EdgeInsets.symmetric(horizontal: 20.0, vertical: 8.0),
        elevation: 2.0,
        child: Padding(
          padding: EdgeInsets.symmetric(vertical: 12, horizontal: 30),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CustomTextfield(
                  TextInputType.text,
                  'Enter Employee Name',
                  nameController,
                      (value) {
                    name = value;
                  }
              ),
              SizedBox(height: 20.0,),
              CustomTextfield(
                  TextInputType.text,
                  'Enter Employee City',
                  cityController,
                      (value) {
                    city = value;
                  }
              ),
              SizedBox(height: 20.0,),
              CustomTextfield(
                  TextInputType.text,
                  'Enter Employee Mentor Name',
                  mentorController,
                      (value) {
                    mentor = value;
                  }
              ),
              SizedBox(height: 20.0,),
              RoundButton(
                  'ADD',
                  Color(0xFF033d5b),
                      () {
                    Map<String, dynamic> empData = {
                      'name': name,
                      'city': city,
                      'mentor': mentor,
                    };
                    curdObj.addData(empData);
                    clear();
                  }),
            ],
          ),),
      ),
    );
  }
}